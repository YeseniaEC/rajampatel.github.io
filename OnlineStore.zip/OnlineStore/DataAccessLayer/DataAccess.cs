﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace DataAccessLayer
{
    public class DataAccess
    {
        string ConnectString = "Server=STLVDUSSDEV043\\SQLEXPRESS;Database=OnlineStore;Trusted_Connection=True;";
        public DataSet GetCustomers()
        {
            DataSet dsCustomer = new DataSet();
            SqlConnection objConn = new SqlConnection(ConnectString);
            objConn.Open();
            SqlDataAdapter daAuthors = new SqlDataAdapter("Select * From customer", objConn);
            daAuthors.Fill(dsCustomer,"customers");
            objConn.Close();
            objConn.Dispose();
            return dsCustomer;
        }
        public DataSet GetCustomerbyName(string pfirstname, string plastname)
        {
            DataSet dsCustomer = new DataSet();
            SqlConnection objConn = new SqlConnection(ConnectString);
            objConn.Open();
            string strquery = "Select * From customer where firstname = '" + pfirstname + "' and lastname = '" + plastname + "'";
            SqlDataAdapter daAuthors = new SqlDataAdapter(strquery, objConn);
            daAuthors.Fill(dsCustomer, "customer");
            objConn.Close();
            objConn.Dispose();
            return dsCustomer;
        }
        
        public DataSet GetCustomersProc()
        {
            DataSet dsCustomer = new DataSet();
            SqlConnection objConn = new SqlConnection(ConnectString);
            objConn.Open();
            SqlCommand cmd = new SqlCommand("getcustomers", objConn);
            //cmd.Parameters.AddWithValue("@parametername", value);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = cmd;
            da.Fill(dsCustomer,"customerdb");
            objConn.Close();
            objConn.Dispose();
            return dsCustomer;
        }
    }
}
