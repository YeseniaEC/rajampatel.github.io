﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DataAccessLayer;

namespace TestOnlineStore
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnShowCustomer_Click(object sender, EventArgs e)
        {
            DataAccess daCustomer = new DataAccess();
            dgvCustomers.DataSource = daCustomer.GetCustomers();
            dgvCustomers.DataMember = "customers";
            dgvCustomers.Refresh();
        }

        private void btnSearchCustomer_Click(object sender, EventArgs e)
        {
            DataAccess daCustomer = new DataAccess();
            dgvCustomers.DataSource = daCustomer.GetCustomerbyName(tbFirstName.Text, tbLastName.Text);
            dgvCustomers.DataMember = "customer";
            dgvCustomers.Refresh();
        }

        private void btnShowCustomerProc_Click(object sender, EventArgs e)
        {
            DataAccess daCustomer = new DataAccess();
            dgvCustomers.DataSource = daCustomer.GetCustomersProc();
            dgvCustomers.DataMember = "customerdb";
            dgvCustomers.Refresh();
        }
    }
}
