﻿var app = angular.module('myApp', [])
.controller('mainController', [ '$scope', function ($scope) {
    $scope.message = "Main Content";
}]);
angular.element(document).ready(function () { angular.bootstrap(document, ['myApp']) });