﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OnlineStoreAPI
{
    public class Address
    {
        #region "Class Variables/Properties"
        int id;
        string add1;
        string add2;
        string city;
        string state;
        string addtype;
        #endregion "Class Variables/Properties"
        
        #region "Get/Set"
        public int ID
        {
            get { return id; }
            set { id = value; }
        }
        public string Add1
        {
            get { return add1; }
            set { add1 = value; }
        }
        public string Add2
        {
            get { return add2; }
            set { add2 = value; }
        }
        public string City
        {
            get { return city; }
            set { city = value; }
        }
        public string State
        {
            get { return state; }
            set { state = value; }
        }
        public string Addtype
        {
            get { return addtype; }
            set { addtype = value; }
        }
        #endregion "Get/Set"


    }
}