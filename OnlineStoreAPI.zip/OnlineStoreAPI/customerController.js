﻿

app.controller('customerController', ['$scope', 'customerService', function ($scope, customerService) {
    $scope.gridtype = "All Customers!";

    $scope.customers = {
        ID: "",
        FirstName: "",
        LastName: "",
        Phone: ""
    };

    customerService.getCustomers($scope);
}])

app.service('customerService', ['$http', function ($http) {
    this.getCustomers = function ($scope) {
        return $http({
            method: "GET",
            url: "http://localhost:51891/api/customer/getcustomers",
            headers: { 'Content-Type': 'application/json' }
        }).success(function (data) {
            $scope.customers = data;
            console.log(data);
        }).error(function (data) {
            console.log(data);
        });;
    };
}]);