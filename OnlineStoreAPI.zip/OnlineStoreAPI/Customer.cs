﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

namespace OnlineStoreAPI
{
    public class Customer
    {
        #region "Class Variables/Properties"
        int id;
        string firstname;
        string lastname;
        string phone;
        #endregion "Class Variables/Properties"

        #region "Get/Set"
        public int ID
        {
            get { return id; }
            set { id = value; }
        }
        public string Firstname
        {
            get { return firstname; }
            set { firstname = value; }
        }
        public string Lastname
        {
            get { return lastname; }
            set { lastname = value; }
        }
        public string Phone
        {
            get { return phone; }
            set { phone = value; }
        }
        #endregion "Get/Set"
        public List<Customer> getCustomers()
        {
            DataAccessLayer.DataAccess da = new DataAccessLayer.DataAccess();
            DataSet dsCustomer = da.GetCustomers();

            var custList = dsCustomer.Tables[0].AsEnumerable().Select(dataRow => new Customer {
                                                                                                ID = dataRow.Field<int>("ID"),
                                                                                                Firstname = dataRow.Field<string>("FirstName"),
                                                                                                Lastname = dataRow.Field<string>("LastName"),
                                                                                                Phone = dataRow.Field<string>("Phone")

            }).ToList() ;
            return custList;
        }
    }
}