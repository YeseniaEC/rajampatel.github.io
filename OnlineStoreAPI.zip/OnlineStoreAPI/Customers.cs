﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OnlineStoreAPI
{
    public class Customers
    {
        public List<Customer> customers = new List<Customer>();
        public List<Address> customeraddress = new List<Address>();
    }
}